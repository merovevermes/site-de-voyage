# a=int(input())
# b=int(input())
# if a>b:
	# print("a est Superieur")
# elif a==b:
	# print("egal")
# else:
	# print("inferieur")
	
			
# a=int(input())
# b=int(input())
# op=input()
# if op=="*":
	# print(a*b)
# elif op=="+":
	# print(a+b)
# elif op=="-":
	# print(a-b)
# elif op=="/":
	# print(a/b)
# else:
	# print("erreur")

# a=int(input())
# if(10<a<20 or 50<a<100):
	# print("a dans l'intervalle")
# else:
	# print("en dehors de l'intervalle")

# a=int(input())
# b=int(input())
# c=int(input())
# if a<b and a<c:
	# if b<c:
		# print(a,b,c)
	# else:
		# print(a,c,b)
# if b<a and b<c:
	# if a<c:
		# print(b,a,c)
	# else:
		# print(b,c,a)
# if c<a and c<b:
	# if a<b:
		 # print(c,a,b)
	# else:
		# print(c,b,a)
		
# a=int(input())
# if a>2000 and a<5000 :
	# a=a*0.99
# print(a)
# if a>5000:	
	# a=a-2*0.98
	# print (a)                                                                                                                                                  
